<?php 

return [
    'driver' => 'database'
];