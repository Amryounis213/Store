<?php


return [
    'categories.view-any' => 'Veiw any Category',
    'categories.view' => 'Veiw Category',
    'categories.create' => 'Create new Category',
    'categories.update' => 'Update  Category',
    'categories.delete' => 'delete  Category',

    'roles.view-any' => 'Veiw any roles',
    'roles.view' => 'Veiw roles',
    'roles.create' => 'Create new roles',
    'roles.update' => 'Update  roles',
    'roles.delete' => 'delete  roles',

    'products.view-any' => 'Veiw any products',
    'products.view' => 'Veiw products',
    'products.create' => 'Create new products',
    'products.update' => 'Update  products',
    'products.delete' => 'delete  products',

];

$config = include 'abilities.php';
