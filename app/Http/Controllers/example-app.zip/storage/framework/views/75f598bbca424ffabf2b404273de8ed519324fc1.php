
   <?php if($errors->any()): ?>
     <div class="alert alert-danger">
       <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><?php echo e($message); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </ul>
     </div>
   <?php endif; ?>
   <div class="form-group">
      <label for="exampleFormControlInput1">Role Name</label>
      <input type="text" name="name" class="form-control" id="exampleFormControlInput1"  value="<?php echo e($role->name ?? ''); ?>" placeholder="name of category">
    </div>
    <div class="form-group">
      <?php $__currentLoopData = config('abilities'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" name="abilities[]" value="<?php echo e($key); ?>" <?php if(in_array($key , $role->abilities ?? [])): ?> checked <?php endif; ?> >
        <label class="form-check-label" for="flexCheckDefault">
          <?php echo e($value); ?>

        </label>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <button type="submit" class="btn btn-primary"><?php echo e($button); ?></button><?php /**PATH C:\wamp64\www\example-app\resources\views/admin/roles/_form.blade.php ENDPATH**/ ?>