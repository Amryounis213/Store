<div class="form-group">
    <label for="<?php echo e($id ?? $name); ?>"><?php echo e($label); ?></label>
    <input 
     type="<?php echo e($type ?? 'text'); ?>"
     name="<?php echo e($name); ?>" 
     id="<?php echo e($id ?? $name); ?>"
     class="form-control" 
     value="<?php echo e(old($name , $value ?? null)); ?>" 
     >
</div><?php /**PATH C:\wamp64\www\example-app\resources\views/components/form-input.blade.php ENDPATH**/ ?>