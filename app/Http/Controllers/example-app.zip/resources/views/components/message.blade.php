Products Count Now:<strong style="color: red"> {{$count}} </strong>
{{--@if (Session::has('success'))

    Products Count Now: {{$count}}

@endif--}}