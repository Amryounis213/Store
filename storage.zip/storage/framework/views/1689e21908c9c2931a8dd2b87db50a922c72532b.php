Products Count Now:<strong style="color: red"> <?php echo e($count); ?> </strong>
<?php /**PATH C:\wamp64\www\example-app\resources\views/components/message.blade.php ENDPATH**/ ?>