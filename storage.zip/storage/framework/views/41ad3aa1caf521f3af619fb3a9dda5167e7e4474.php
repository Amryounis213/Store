
<?php $__env->startSection('content'); ?>

    <div class="app-title">
      
    </div>
    <div class="row">
   
     
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="tile">
          <h3 class="tile-title">Chat</h3>
          <div class="messanger">
            <div id="messages" class="messages">
              
            </div>
            <form id="chat-form" method="POST" action="<?php echo e(route('chat.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="sender">
              <input name="message" type="text" placeholder="Send Message">
              <button class="btn btn-primary" type="submit"><i class="fa fa-lg fa-fw fa-paper-plane"></i></button>
            </div>
            </form>
          </div>
        </div>
      </div>
     
    </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\example-app\resources\views/admin/chat.blade.php ENDPATH**/ ?>