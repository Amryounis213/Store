
   <?php if($errors->any()): ?>
     <div class="alert alert-danger">
       <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><?php echo e($message); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </ul>
     </div>
   <?php endif; ?>
    <div class="form-group">
      <label for="exampleFormControlInput1">Name</label>
      <input type="text" name="user_id" class="form-control" id="exampleFormControlInput1"  value="<?php echo e($user->name ?? ''); ?>" disabled readonly>
    </div>
    <div class="form-group">
      <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="role_id" value="<?php echo e($role->id); ?>">
        <label class="form-check-label" for="flexRadioDefault1">
          <?php echo e($role->name); ?>

        </label>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <button type="submit" class="btn btn-primary"><?php echo e($button); ?></button><?php /**PATH C:\wamp64\www\example-app\resources\views/admin/users/_form.blade.php ENDPATH**/ ?>