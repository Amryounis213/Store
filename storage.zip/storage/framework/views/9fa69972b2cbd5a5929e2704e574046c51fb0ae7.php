
   <?php if($errors->any()): ?>
     <div class="alert alert-danger">
       <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><?php echo e($message); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </ul>
     </div>
   <?php endif; ?>
   <div class="form-group">
      <label for="exampleFormControlInput1">Category Name</label>
      <input type="text" name="name" class="form-control" id="exampleFormControlInput1"  value="<?php echo e($category->name); ?>" placeholder="name of category">
    </div>
    <div class="form-group">
      <label for="exampleFormControlSelect1">Parent</label>
      <select name="parent_id" class="form-control" id="parent_id">
        <option value="0">--Select Parent--</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($parent->id); ?>" <?php if($parent->id == $category->parent_id): ?> selected <?php endif; ?>><?php echo e($parent ->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group">
      <label for="exampleFormControlTextarea1">Description</label>
      <textarea name="description" class="form-control" id="description"  rows="3"><?php echo e($category->description); ?></textarea>
    </div>
    <div class="form-group">
        <label for="image">Image</label>
        <input type="file" name="image" class="form-control" id="image" >
    </div>

    <div class="form-check">
        <input class="form-check-input" type="radio" name="status" id="status" value="Active" <?php if($category->status == "Active"): ?> checked <?php endif; ?> >
        <label class="form-check-label" for="status">
          Active
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="status" id="status" value="Draft" <?php if($category->status == "Draft"): ?> checked <?php endif; ?>>
        <label class="form-check-label" for="status">
          Draft
        </label>
      </div>
      <button type="submit" class="btn btn-primary"><?php echo e($button); ?></button><?php /**PATH C:\wamp64\www\example-app\resources\views/admin/categories/_form.blade.php ENDPATH**/ ?>