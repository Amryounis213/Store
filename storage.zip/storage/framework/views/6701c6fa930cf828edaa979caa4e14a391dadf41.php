

<?php $__env->startSection('content'); ?>

  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"></i>Roles Table</h1>
      <p>Roles This Store</p>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Control Panel</li>
      <li class="breadcrumb-item active"><a href="#">Roles</a></li>
    </ul>
  </div>
  <div class="col-md-12">
       
        
    <div class="tile">
      <?php if(Session::has('success')): ?>
      <div class="alert alert-success" role="alert">
       <?php echo e(Session::get('success')); ?>

       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
      </div>
      <?php endif; ?>
      <div class="tile-body">
        <div  class="col-md-12 p-2 m-2 row ">
          <div class="col-md-6 justify-content-start align-items-center">
            <h5 class="h5"><i class="fa fa-table"></i><strong> Roles Table</strong></h5>
          </div>
          <div class="row col-md-6 justify-content-end">
              <a style="height: 30px; width:100px;" href="#" class="btn btn-warning d-flex justify-content-center align-items-center ml-1"><i class="fa fa-print "></i><small>PDF</small></a>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.create')): ?>
              <a style="height: 30px; width:100px;" href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary d-flex justify-content-center align-items-center ml-1"><i class="fa fa-plus "></i><small>New</small></a>
              <?php endif; ?>
              
          </div>
          
          
        </div>
          <input style="width: 100%; padding:5px ; margin-bottom:5px;" type="text" name="search" placeholder="Search...">
        
        <div class="table-responsive">
          
          <table class="table table-hover table-bordered" id="sampleTable">
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Options</th>
                
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($role->id); ?></td> 
                <td><?php echo e($role->name); ?></td> 

                <td>
                  <div class="row justify-content-center">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.update')): ?>
                    <a style="height: 30px; width:100px;" href="<?php echo e(route('roles.edit',$role->id)); ?>" class="btn btn-warning d-flex justify-content-center align-items-center ml-1"><i class="fa fa-edit "></i><small>edit</small></a>
                    <?php endif; ?>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.delete')): ?>
                    <a style="height: 30px; width:100px;" href="#" class="btn btn-danger d-flex justify-content-center align-items-center ml-1"><i class="fa fa-delete "></i><small>delete</small></a>
                   <?php endif; ?>
                </div>
                </td>
            <tr> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
             
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

 

    
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\example-app\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>