  <!-- PRODUCTS -->
<?php $__env->startSection('content'); ?>
  <section class="section products">
    <div class="products-layout container">
      <div class="col-1-of-4">
        <div>
          <div class="block-title">
            <h3>Category</h3>
          </div>

          <ul class="block-content">
            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span>Shoes</span>
                <small>(10)</small>
              </label>
            </li>

            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span>Bags</span>
                <small>(7)</small>
              </label>
            </li>

            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span> Accessories</span>
                <small>(3)</small>
              </label>
            </li>

            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span>Clothings</span>
                <small>(3)</small>
              </label>
            </li>
          </ul>
        </div>

        <div>
          <div class="block-title">
            <h3>Brands</h3>
          </div>

          <ul class="block-content">
            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span>Gucci</span>
                <small>(10)</small>
              </label>
            </li>

            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span>Burberry</span>
                <small>(7)</small>
              </label>
            </li>

            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span> Accessories</span>
                <small>(3)</small>
              </label>
            </li>

            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span>Valentino</span>
                <small>(3)</small>
              </label>
            </li>

            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span>Dolce & Gabbana</span>
                <small>(3)</small>
              </label>
            </li>

            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span>Hogan</span>
                <small>(3)</small>
              </label>
            </li>

            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span>Moreschi</span>
                <small>(3)</small>
              </label>
            </li>

            <li>
              <input type="checkbox" name="" id="">
              <label for="">
                <span>Givenchy</span>
                <small>(3)</small>
              </label>
            </li>
          </ul>
        </div>
      </div>
      <div class="col-3-of-4">
        <form action="<?php echo e(route('Filter_Products')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="item">
            <label for="sort-by">Sort By</label> 
            <select name="name" id="sort-by" required onchange="this.form.submit()">

              <option  value="name" selected="selected">Name</option>
              <option  value="price">Price</option>
              <option  value="search_api_relevance">Relevance</option>
              <option  value="created">Newness</option>
            </select>

          </div>
          <div class="item">
            <label for="order-by">Order</label>
            <select name="order-by" id="sort-by">
              <option value="ASC" selected="selected">ASC</option>
              <option value="DESC">DESC</option>
            </select>
          </div>
          <a href="">Apply</a>
        </form>

        <div class="product-layout">
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="product">
            <div class="img-container">
              <img style="height: 300px" src="<?php echo e(asset('./storage/'.$product->image)); ?>" alt="" />
              
      
                <form class="addCart border-0" action="#" method="POST">
                  <?php echo csrf_field(); ?>
                  <input hidden name="product_id" value="<?php echo e($product->id); ?>">
                  <input hidden name="quantity" type="number" value="1">
                  <i class="fas fa-shopping-cart"></i>
                </form>
      
               
              
      
              <ul class="side-icons">
                <span><i class="fas fa-search"></i></span>
                <span><i class="far fa-heart"></i></span>
                <span><i class="fas fa-sliders-h"></i></span>
              </ul>
            </div>
            <div class="bottom">
              <a href="productDetails.html"><?php echo e($product->name); ?></a>
              <div class="price">
                <span><?php echo e($product->price); ?></span>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
    
        </div>

        <!-- PAGINATION -->
        <ul class="pagination">
          <span>1</span>
          <span>2</span>
          <span class="icon">››</span>
          <span class="last">Last »</span>
        </ul>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
 

<?php $__env->startSection('scripts'); ?>
<script>




  (function ($) {


    $(".addCart").click(function(e){
      e.preventDefault();
    var form = $(this);
    $.ajax({
      type: form.attr('method'),
      url: "<?php echo e(route('cart')); ?>",
      data: form.serialize()
    }).done(function(data) {
      swal({
        toast: true,
        position: 'bottom-end',
        icon: 'success',
        title: 'Products Add Successfully',
        showConfirmButton: true,
        timer: 1500
      });
    }).fail(function(data) {
      // Optionally alert the user of an error here...
    });

    })
  })(jQuery);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\example-app\resources\views/user/products.blade.php ENDPATH**/ ?>