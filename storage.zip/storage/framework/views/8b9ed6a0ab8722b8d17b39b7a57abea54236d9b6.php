

<?php $__env->startSection('content'); ?>

  <div class="app-title">
    <div>
      <h1><i class="fa fa-th-list"></i>Categories Table</h1>
      <p>Categories This Store</p>
    </div>
    <ul class="app-breadcrumb breadcrumb side">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item">Control Panel</li>
      <li class="breadcrumb-item active"><a href="#">Categories</a></li>
      <li class="breadcrumb-item active"><a href="#">edit</a></li>
    </ul>
  </div>
  <div class="col-md-12">
       
        
    <div class="tile">
      <?php if(Session::has('message')): ?>
      <div class="alert alert-success" role="alert">
       <?php echo e(Session::get('message')); ?>

       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
      </div> 
      <?php endif; ?>
      <div class="tile-body">
        <div  class="col-md-12 p-2 m-2 row ">
          <div class="col-md-6 justify-content-start align-items-center">
            <h5 class="h5"><i class="fa fa-table"></i><strong> Categories Table</strong></h5>
          </div>  
        </div>

      </div>
      <form method="POST" action="<?php echo e(route('categories.update',$category->id)); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
        <?php echo $__env->make('admin.categories._form' , ['button'=> 'Update'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </form>
    </div>
  </div>

 

    
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\example-app\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>